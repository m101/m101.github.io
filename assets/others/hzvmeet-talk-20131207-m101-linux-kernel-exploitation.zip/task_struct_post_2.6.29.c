/*
Kernel 2.6.30
include/linux/sched.h
*/

struct task_struct {
/* ... */

/* process credentials */
	const struct cred *real_cred;	/* objective and real subjective task
					 * credentials (COW) */
	const struct cred *cred;	/* effective (overridable) subjective task
					 * credentials (COW) */
	struct mutex cred_exec_mutex;	/* execve vs ptrace cred calculation mutex */
/* ... */
};

