SYSCALL_DEFINE2(ptree, struct prinfo *, buf, unsigned int *, nr)
{
    /* ... */
	count = 0;
    /* ... */

    // nr is an arbitrary kernel address
    // so this call fail and we go to out
	if (get_user(max, nr)) {
		ret = -EFAULT;
		goto out;
	}

    /* ... */

out:
    // nr is our kernel address
    // count is equal to 0
    // -> put zero to an arbitrary location!
	*nr = count;
	return ret;
}

