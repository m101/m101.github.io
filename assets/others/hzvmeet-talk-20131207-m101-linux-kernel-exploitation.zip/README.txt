Hello,

These files are part of the presentation I did at a HZV meet on the December 7th
2013.

I used the tool pygmentize for coloring the code in my slides:
pygmentize -f rtf -o vmsplice.rtf vmsplice.c

I used LibreOffice for elaborating the slides.

The Kernel used for this presentation:
- 2.6.23 : vmsplice, pre 2.6.29 payload, sendpage (with CVE-2009-2692)
- 2.6.30 : rds, /dev/net/tun, post 2.6.29 payload

There is a blog post detailing a bit more some slides on my blog:
https://binholic.blogspot.com/

I hope you enjoy it,

Should you have any feedback, please send it to me,

Cheers,

m_101

