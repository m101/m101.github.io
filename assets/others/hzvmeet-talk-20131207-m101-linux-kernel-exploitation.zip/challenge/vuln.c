int ptree (int val, char *ptr)
{
    val = 0;

    if (ptr == kernel_addr)
        goto out;

    /* code */
    /* modify val */
    /* end code */

out:
    *ptr = val; // *ptr = NULL;

    return *ptr;
}

