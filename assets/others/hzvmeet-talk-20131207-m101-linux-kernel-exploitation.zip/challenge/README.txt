In this exploit, I issue 3 ptree() call, which is ugly.
But I did so in order to do the following writes:

20  21  22  23  24  25  26  27
w   w   w   w
    w   w   w   w
                        w   w   w   w
w   w   w   w   w       w   w   w   w

So I only keep a precise bit.

There is a cleaner way which involves using bit arithmetics and aligning our
mmap() on a PAGE_SIZE boundary.

Cheers,

m_101

