int test_count1 (void)
{
    unsigned long addr_kernel;
    int count;
    struct prinfo *processes;

    count = 32768;
    processes = malloc(sizeof(struct prinfo) * count);
    if (!processes) {
        perror("processes");
        return EXIT_FAILURE;
    }

    for (addr_kernel = ADDR_KERNEL; addr_kernel < ADDR_KERNEL + PAGE_SIZE * 32; addr_kernel++) {
        if (ptree(processes, (unsigned int *) addr_kernel)) {
            perror("ptree");
            return EXIT_FAILURE;
        }

        dump(processes, sizeof(struct prinfo), 16);
        printf("\n");
    }

    return 0;
}

int test_count2 (void)
{
    unsigned long addr_kernel;
    unsigned int count;
    struct prinfo *processes;

    count = PAGE_SIZE * PAGE_SIZE;
    processes = malloc(sizeof(struct prinfo) * count);
    if (!processes) {
        perror("processes");
        return EXIT_FAILURE;
    }

    for (addr_kernel = ADDR_KERNEL; addr_kernel < ADDR_KERNEL + PAGE_SIZE * 32; addr_kernel++) {
        if (ptree(processes, &count)) {
            perror("ptree");
            return EXIT_FAILURE;
        }

        dump(processes, sizeof(struct prinfo), 16);
        printf("\n");
    }

    return 0;
}

int test_processes (void)
{
    unsigned long addr_kernel;
    unsigned int count;

    for (addr_kernel = ADDR_KERNEL; addr_kernel < ADDR_KERNEL + PAGE_SIZE * 32; addr_kernel++) {
        if (ptree(addr_kernel, &count)) {
            perror("ptree");
            return EXIT_FAILURE;
        }
    }

    return 0;
}
